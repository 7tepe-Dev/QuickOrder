public class Tester {

	public static void main(String[] args) 
	{
		Admin a=Admin.createOrGetAdmin();
		Customer c=new Customer("hakan","2587",userType.CUSTOMER,125);
		a.addNewUserToList();
		c.addNewUserToList();
		try
		{
			User d=UserFactory.createNewUser("Owner");
			//((Owner) d).getRestaurant();
			d.addNewUserToList();
		}
		catch(NullPointerException e)
		{
			System.out.println("bo� atm��s�n abem napiyim.");
		}
		for(User user : User.getAllUsers())
		{
			System.out.println(user.userName);
		}
	}
}